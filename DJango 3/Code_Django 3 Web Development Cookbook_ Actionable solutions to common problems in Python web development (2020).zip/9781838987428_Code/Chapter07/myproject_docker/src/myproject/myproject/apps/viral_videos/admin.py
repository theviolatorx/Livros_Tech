from django.contrib import admin

from .models import ViralVideo

admin.site.register(ViralVideo)
