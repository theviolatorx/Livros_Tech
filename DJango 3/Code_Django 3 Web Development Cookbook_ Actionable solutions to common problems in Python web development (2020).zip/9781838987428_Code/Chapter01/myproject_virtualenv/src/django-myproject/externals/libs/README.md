# Python Libraries

In this directory you can place Python libraries that for some reason cannot be installed from the Python Package Index or version controls.

Some examples:

- Patched libraries
- Private libraries
- Legacy versions

Then use this README file to describe what libraries and versions you are using here.

| Library | Version | Description | Source URL |
|---------|---------|-------------|------------|
|         |         |             |            |
|         |         |             |            |
|         |         |             |            |