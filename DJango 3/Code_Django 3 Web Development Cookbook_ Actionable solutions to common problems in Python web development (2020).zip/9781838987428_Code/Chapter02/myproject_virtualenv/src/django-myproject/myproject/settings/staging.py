from ._base import *

DEBUG = False

WEBSITE_URL = "https://staging.myproject.com"  # without trailing slash
