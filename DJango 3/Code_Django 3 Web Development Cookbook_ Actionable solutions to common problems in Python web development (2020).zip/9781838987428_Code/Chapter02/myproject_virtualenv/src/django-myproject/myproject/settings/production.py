from ._base import *

DEBUG = False

WEBSITE_URL = "https://example.com"  # without trailing slash
